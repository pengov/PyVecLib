# vecLib
*vecLib/PyVecLib* is cross plateform vector library for Python.
He can bu used for vectors manipulation for video games or for simulations.

* vecLib [Github]
* vecLib [Pypi]

vecLib is a pure python library so he didn't need some requirements except python>=3.4

## Installation
vecLib is installable from PyPi
```
pip install --upgrade vecLib
```
## Installation from source
if you're reading `README` from a source distribution, you can install vecLib with:
```bash
pip install ./dist/vecLib-[VERSION]-py3-none-any.whl
```

## Contact
You can contact me to *`pengovn@gmail.com`*

[Github]: https://github.com/pengovn/PyVecLib
[pypi]: https://pypi.org/project/VecLib/