from vecLib.vec import Vec
from vecLib.vec2d import Vec2d
from vecLib.vec3d import Vec3d

__version__ = "1.2.1"