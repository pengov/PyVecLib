from setuptools import find_packages, setup

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name="vecLib",
    version="1.2.0",
    description="Python lib for vector for n dimensions",
    long_description=long_description,
    long_description_content_type="text/markdown",
    keywords="vector vectors 2d 3d",
    author="Nicolas Pengov",
    author_email="pengovn@gmail.com",
    url="https://github.com/pengovn/PyVecLib",
    license="MIT",
    packages=find_packages(include=["vecLib"]),
    install_requires=[],
    python_requires='>=3.4',
)