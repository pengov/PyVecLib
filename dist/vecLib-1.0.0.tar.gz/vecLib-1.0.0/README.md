# vecLib
*vecLib/PyVecLib* is cross plateform vector library for Python.
He can bu used for vectors manipulation for video games or for simulations.

* vecLib [Github]
* vecLib [Pypi]

[Github]: https://github.com/pengovn/PyVecLib
[pypi]: https://pypi.org/project/VecLib/

vecLib